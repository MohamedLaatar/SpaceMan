#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>
#include "entite_secondaire.h"


int main(int argc,char **argv[])
{
    SDL_Surface *screen =NULL;
    SDL_Surface *bg =NULL;
    SDL_Rect menu;

//###################################################
    SDL_Surface *hero = IMG_Load("right.png");
    SDL_Rect pos_hero;
    pos_hero.x = 100;
    pos_hero.y = 300;
    SDL_Rect h;
    h.x = 0;
    h.y = 0;
    h.w = 207;
    h.h = 200;
	int jump = 0 , gravity = 0 , speed = 0,sens =0;



//###################################################





    menu.x=0;
    menu.y=0;
    bg = IMG_Load("bg.png");

    SDL_Init(SDL_INIT_EVERYTHING);

    SDL_Event event;
    screen=SDL_SetVideoMode(1000,570, 32,SDL_HWSURFACE| SDL_DOUBLEBUF);
    SDL_WM_SetCaption("game",NULL);

    entite_secondaire es;

    init_es(&es);

    int collision_right = 0;
    int collision_left = 0;
    int collision_top = 0;

    int continuer=1;
    while(continuer == 1)
    {
        SDL_PollEvent(&event);
        switch(event.type)
        {
        case SDL_QUIT:
            continuer=0;

            break;

        case SDL_KEYDOWN:
            switch(event.key.keysym.sym)
            {
            case SDLK_ESCAPE:
                continuer=0;

                break;

            case SDLK_RIGHT :
            {
			sens = 0;
                    pos_hero.x +=40;
            }
            break;

            case SDLK_LEFT :
            {
			sens = 1;
                    pos_hero.x -=40;
            }
            break;

            case SDLK_UP :
            {
                    pos_hero.y -=40;
            }
            break;

            case SDLK_DOWN :
            {
			if ( collision_top != 1 )
                    		pos_hero.y +=40;
            }
            break;

            }
            break;

        }// taskiret les events mtaa les boutons

	detect_collision( &es, &pos_hero, &collision_right,&collision_left,&collision_top);

        if ( collision_right == 0 && collision_left == 0 && collision_top == 0)
        {
            dep (&es);
            animation(&es);

        }



        SDL_BlitSurface(bg,NULL,screen,&menu);
        blit_entite_secondaire ( &es, screen);
        SDL_BlitSurface(hero,&h,screen,&pos_hero);
        SDL_Flip(screen);
        SDL_Delay(100);





    } // taskiret continuer
    free_surface_es(&es);
    SDL_FreeSurface(hero);
    SDL_FreeSurface(bg);
    SDL_Quit();

    return EXIT_SUCCESS ;
}


#include "entite_secondaire.h"

void init_es( entite_secondaire* es )
{
	es->left = IMG_Load("left.png");
	es->right = IMG_Load("right.png");
	es->pos_es.x = 300;
	es->pos_es.y = 300;
	es->frame=0;
	es->sens=0;

	es->tab_right[0].x= 0;
	es->tab_right[0].y= 0;
	es->tab_right[0].w= 207;
	es->tab_right[0].h= 200;

	es->tab_right[1].x= 211;
	es->tab_right[1].y= 0;
	es->tab_right[1].w= 151;
	es->tab_right[1].h= 200;

	es->tab_right[2].x= 369;
	es->tab_right[2].y= 0;
	es->tab_right[2].w= 164;
	es->tab_right[2].h= 200;

	es->tab_right[3].x= 539;
	es->tab_right[3].y= 0;
	es->tab_right[3].w= 184;
	es->tab_right[3].h= 200;

	es->tab_right[4].x= 729;
	es->tab_right[4].y= 0;
	es->tab_right[4].w= 185;
	es->tab_right[4].h= 200;

	es->tab_right[5].x= 919;
	es->tab_right[5].y= 0;
	es->tab_right[5].w= 202;
	es->tab_right[5].h= 200;


//########################################

	es->tab_left[0].x= 913;
	es->tab_left[0].y= 0;
	es->tab_left[0].w= 208;
	es->tab_left[0].h= 320;

	es->tab_left[1].x= 758;
	es->tab_left[1].y= 0;
	es->tab_left[1].w= 151;
	es->tab_left[1].h= 320;

	es->tab_left[2].x= 587;
	es->tab_left[2].y= 0;
	es->tab_left[2].w= 164;
	es->tab_left[2].h= 320;

	es->tab_left[3].x= 397;
	es->tab_left[3].y= 0;
	es->tab_left[3].w= 184;
	es->tab_left[3].h= 320;

	es->tab_left[4].x= 206;
	es->tab_left[4].y= 0;
	es->tab_left[4].w= 185;
	es->tab_left[4].h= 320;

	es->tab_left[5].x= 0;
	es->tab_left[5].y= 0;
	es->tab_left[5].w= 201;
	es->tab_left[5].h= 320;

}

void animation ( entite_secondaire* es)
{
	es->frame++;
	if ( es->frame > 5 )
	{
		es->frame=0;
		if ( es->sens == 0 )
		{
			es->sens=1;
		}
		else
		{
			es->sens=0;
		}
	}

}

void dep ( entite_secondaire* es)
{
	if ( es->sens == 0 )
	{
		es->pos_es.x +=60;
	}
	else
	{
		es->pos_es.x -=60;
	}

}


void blit_entite_secondaire ( entite_secondaire *es, SDL_Surface* screen)
{
	if ( es->sens == 0) 
	{
		SDL_BlitSurface(es->right, &es->tab_right[es->frame] , screen , &es->pos_es );
	}
	else
	{
		SDL_BlitSurface(es->left, &es->tab_left[es->frame] , screen , &es->pos_es );
	}
}


void detect_collision( entite_secondaire *es , SDL_Rect* pos_hero , int* collision_right,int* collision_left,int* collision_top)
{
	

	if ( es->pos_es.x - (*pos_hero).x - 150 <= 60 && es->pos_es.x - (*pos_hero).x - 150 >= 0  && (*pos_hero).y == 300)
	{
		*collision_left = 1;
	}
	else if ( (*pos_hero).x - es->pos_es.x - 150 <= 60 && (*pos_hero).x - es->pos_es.x - 150 >= 0 && (*pos_hero).y == 300)
	{
		*collision_right = 1;
	}	
	else if ( (*pos_hero).x >=  es->pos_es.x - 200 && (*pos_hero).x <=  es->pos_es.x + 150 && (*pos_hero).y + 200 - es->pos_es.y >= 0 && (*pos_hero).y + 200 - es->pos_es.y <= 60 )   
	{
		*collision_top = 1;
	}
	else
	{
		*collision_left = 0;
		*collision_right = 0;
		*collision_top = 0;
	}
}


void free_surface_es( entite_secondaire *es )
{
	SDL_FreeSurface(es->right);
	SDL_FreeSurface(es->left);
}


 















#ifndef HERO_H_INCLUDED
#define HERO_H_INCLUDED
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>


struct entite_secondaire
{
	SDL_Surface *left,*right;
	SDL_Rect pos_es;
	SDL_Rect tab_left[6],tab_right[6];
	int frame,sens;
	
};
typedef struct entite_secondaire entite_secondaire; 

void dep ( entite_secondaire* es);
void init_es( entite_secondaire* es );
void animation ( entite_secondaire* es);
void blit_entite_secondaire ( entite_secondaire *es, SDL_Surface* screen);
void free_surface_es( entite_secondaire *es );
void detect_collision( entite_secondaire *es , SDL_Rect* pos_hero , int* collision_right,int* collision_left,int* collision_top);
#endif // HERO_H_INCLUDED
